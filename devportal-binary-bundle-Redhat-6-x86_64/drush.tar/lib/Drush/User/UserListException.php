<?php

namespace Drush\User;

class UserListException extends \Exception {}
