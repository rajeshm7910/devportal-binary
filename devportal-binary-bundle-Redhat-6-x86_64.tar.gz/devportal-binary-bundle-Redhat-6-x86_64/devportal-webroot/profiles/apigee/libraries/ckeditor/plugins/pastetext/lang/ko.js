﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'ko', {
	button: '텍스트로 붙여넣기',
	title: '텍스트로 붙여넣기'
} );
