﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'ms', {
	alertUrl: 'Sila taip URL untuk fail gambar',
	alt: 'Text Alternatif',
	border: 'Border',
	btnUpload: 'Hantar ke Server',
	button2Img: 'Do you want to transform the selected image button on a simple image?', // MISSING
	hSpace: 'Ruang Melintang',
	img2Button: 'Do you want to transform the selected image on a image button?', // MISSING
	infoTab: 'Info Imej',
	linkTab: 'Sambungan',
	lockRatio: 'Tetapkan Nisbah',
	menu: 'Ciri-ciri Imej',
	resetSize: 'Saiz Set Semula',
	title: 'Ciri-ciri Imej',
	titleButton: 'Ciri-ciri Butang Bergambar',
	upload: 'Muat Naik',
	urlMissing: 'Image source URL is missing.', // MISSING
	vSpace: 'Ruang Menegak',
	validateBorder: 'Border must be a whole number.', // MISSING
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
} );
