﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'sq', {
	anchor: 'Spirancë',
	flash: 'Objekt flash',
	hiddenfield: 'Fushë e fshehur',
	iframe: 'IFrame',
	unknown: 'Objekt i Panjohur'
} );
