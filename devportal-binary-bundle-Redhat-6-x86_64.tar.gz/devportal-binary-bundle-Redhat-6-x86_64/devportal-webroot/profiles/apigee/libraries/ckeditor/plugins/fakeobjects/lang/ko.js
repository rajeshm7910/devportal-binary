﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'ko', {
	anchor: '책갈피 삽입/변경',
	flash: 'Flash Animation', // MISSING
	hiddenfield: '숨김필드',
	iframe: 'IFrame',
	unknown: 'Unknown Object' // MISSING
} );
