﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'eu', {
	anchor: 'Aingura',
	flash: 'Flash Animazioa',
	hiddenfield: 'Ezkutuko Eremua',
	iframe: 'IFrame',
	unknown: 'Objektu ezezaguna'
} );
