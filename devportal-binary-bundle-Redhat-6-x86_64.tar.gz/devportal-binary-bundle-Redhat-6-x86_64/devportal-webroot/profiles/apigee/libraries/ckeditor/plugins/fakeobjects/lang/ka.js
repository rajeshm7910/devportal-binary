﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'ka', {
	anchor: 'ღუზა',
	flash: 'Flash ანიმაცია',
	hiddenfield: 'მალული ველი',
	iframe: 'IFrame',
	unknown: 'უცნობი ობიექტი'
} );
