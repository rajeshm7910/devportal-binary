﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'id', {
	alertUrl: 'Mohon tulis URL gambar',
	alt: 'Teks alternatif',
	border: 'Batas',
	btnUpload: 'Kirim ke Server',
	button2Img: 'Do you want to transform the selected image button on a simple image?', // MISSING
	hSpace: 'HSpace', // MISSING
	img2Button: 'Do you want to transform the selected image on a image button?', // MISSING
	infoTab: 'Info Gambar',
	linkTab: 'Tautan',
	lockRatio: 'Lock Ratio', // MISSING
	menu: 'Image Properties', // MISSING
	resetSize: 'Reset Size', // MISSING
	title: 'Image Properties', // MISSING
	titleButton: 'Image Button Properties', // MISSING
	upload: 'Unggah',
	urlMissing: 'Image source URL is missing.', // MISSING
	vSpace: 'VSpace',
	validateBorder: 'Border must be a whole number.', // MISSING
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
} );
